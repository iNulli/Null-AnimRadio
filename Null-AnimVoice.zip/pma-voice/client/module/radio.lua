local radioChannel = 0
local radioNames = {}
local disableRadioAnim = false
local radioProp = nil
local radioPressed = false

--- event syncRadioData
--- syncs the current players on the radio to the client
---@param radioTable table the table of the current players on the radio
---@param localPlyRadioName string the local players name
function syncRadioData(radioTable, localPlyRadioName)
	radioData = radioTable
	logger.info('[radio] Syncing radio table.')
	if GetConvarInt('voice_debugMode', 0) >= 4 then
		print('-------- RADIO TABLE --------')
		tPrint(radioData)
		print('-----------------------------')
	end
	for tgt, enabled in pairs(radioTable) do
		if tgt ~= playerServerId then
			toggleVoice(tgt, enabled, 'radio')
		end
	end
	sendUIMessage({
		radioChannel = radioChannel,
		radioEnabled = radioEnabled
	})
	if GetConvarInt("voice_syncPlayerNames", 0) == 1 then
		radioNames[playerServerId] = localPlyRadioName
	end
end
RegisterNetEvent('pma-voice:syncRadioData', syncRadioData)

--- event setTalkingOnRadio
--- sets the players talking status, triggered when a player starts/stops talking.
---@param plySource number the players server id.
---@param enabled boolean whether the player is talking or not.
function setTalkingOnRadio(plySource, enabled)
    -- If we're on a call we don't want to toggle their voice disabled this will break calls.
    if not callData[plySource] then
        toggleVoice(plySource, enabled, 'radio')
    end
	radioData[plySource] = enabled
	playMicClicks(enabled)
end
RegisterNetEvent('pma-voice:setTalkingOnRadio', setTalkingOnRadio)

--- event addPlayerToRadio
--- adds a player onto the radio.
---@param plySource number the players server id to add to the radio.
function addPlayerToRadio(plySource, plyRadioName)
	radioData[plySource] = false
	if GetConvarInt("voice_syncPlayerNames", 0) == 1 then
		radioNames[plySource] = plyRadioName
	end
	if radioPressed then
		logger.info('[radio] %s joined radio %s while we were talking, adding them to targets', plySource, radioChannel)
		playerTargets(radioData, MumbleIsPlayerTalking(PlayerId()) and callData or {})
	else
		logger.info('[radio] %s joined radio %s', plySource, radioChannel)
	end
end
RegisterNetEvent('pma-voice:addPlayerToRadio', addPlayerToRadio)

--- event removePlayerFromRadio
--- removes the player (or self) from the radio
---@param plySource number the players server id to remove from the radio.
function removePlayerFromRadio(plySource)
	if plySource == playerServerId then
		logger.info('[radio] Left radio %s, cleaning up.', radioChannel)
		for tgt, _ in pairs(radioData) do
			if tgt ~= playerServerId then
				toggleVoice(tgt, false, 'radio')
			end
		end
		sendUIMessage({
			radioChannel = 0,
			radioEnabled = radioEnabled
		})
		radioNames = {}
		radioData = {}
		playerTargets(MumbleIsPlayerTalking(PlayerId()) and callData or {})
	else
		toggleVoice(plySource, false , 'radio')
		if radioPressed then
			logger.info('[radio] %s left radio %s while we were talking, updating targets.', plySource, radioChannel)
			playerTargets(radioData, MumbleIsPlayerTalking(PlayerId()) and callData or {})
		else
			logger.info('[radio] %s has left radio %s', plySource, radioChannel)
		end
		radioData[plySource] = nil
		if GetConvarInt("voice_syncPlayerNames", 0) == 1 then
			radioNames[plySource] = nil
		end
	end
end
RegisterNetEvent('pma-voice:removePlayerFromRadio', removePlayerFromRadio)

--- function setRadioChannel
--- sets the local players current radio channel and updates the server
---@param channel number the channel to set the player to, or 0 to remove them.
function setRadioChannel(channel)
	if GetConvarInt('voice_enableRadios', 1) ~= 1 then return end
	type_check({channel, "number"})
	TriggerServerEvent('pma-voice:setPlayerRadio', channel)
	radioChannel = channel
end

--- exports setRadioChannel
--- sets the local players current radio channel and updates the server
exports('setRadioChannel', setRadioChannel)
-- mumble-voip compatability
exports('SetRadioChannel', setRadioChannel)

--- exports removePlayerFromRadio
--- sets the local players current radio channel and updates the server
exports('removePlayerFromRadio', function()
	setRadioChannel(0)
end)

--- exports addPlayerToRadio
--- sets the local players current radio channel and updates the server
---@param _radio number the channel to set the player to, or 0 to remove them.
exports('addPlayerToRadio', function(_radio)
	local radio = tonumber(_radio)
	if radio then
		setRadioChannel(radio)
	end
end)


--- exports toggleRadioAnim
--- toggles whether the client should play radio anim or not, if the animation should be played or notvaliddance
exports('toggleRadioAnim', function()
	disableRadioAnim = not disableRadioAnim
	TriggerEvent('pma-voice:toggleRadioAnim', disableRadioAnim)
end)

-- exports disableRadioAnim
--- returns whether the client is undercover or not
exports('getRadioAnimState', function()
	return disableRadioAnim
end)

--- check if the player is dead
--- seperating this so if people use different methods they can customize
--- it to their need as this will likely never be changed
--- but you can integrate the below state bag to your death resources.
--- LocalPlayer.state:set('isDead', true or false, false)
function isDead()
	if LocalPlayer.state.isDead then
		return true
	elseif IsPlayerDead(PlayerId()) then
		return true
	end
end


local radioAnimations = {
    ["radio1"] = {
        dictionary = "cellphone@",
        animation = "cellphone_text_read_base",
        bone = 28422, -- عظمة اليد اليمنى
        propPosition = {vector3(0.000000, 0.000000, 0.000000), vector3(0.000000, 0.000000, 0.000000)}
    },
    ["radio2"] = {
        dictionary = "ultra@walkie_talkie",
        animation = "walkie_talkie",
        bone = 18905, -- عظمة الكتف اليمنى
        propPosition = {vector3(0.140000, 0.030000, 0.030000), vector3(-105.877000, -10.943200, -33.721200)}
    },
    ["radio3"] = {
        dictionary = "random@arrests",
        animation = "generic_radio_chatter",
        bone = 28422, -- عظمة الكتف اليمنى
        propPosition = {vector3(0.0750, 0.0230, -0.0230), vector3(-90.0000, 0.0, -59.9999)}
    },
	["radio4"] = {
        dictionary = "anim@male@holding_radio",
        animation = "holding_radio_clip",
        bone = 28422, -- عظمة الكتف اليمنى
        propPosition = {vector3(0.0750, 0.0230, -0.0230), vector3(-90.0000, 0.0, -59.9999)}
    },
}


local currentRadioAnimation = "radio1" -- الأنيميشن الافتراضي

--- تحميل مكتبة الأنيميشن
function LoadAnimDic(dict)
    if not HasAnimDictLoaded(dict) then
        RequestAnimDict(dict)
        while not HasAnimDictLoaded(dict) do
            Wait(0)
        end
    end
end

local radioProp = nil

local function toggleRadioAnimation(pState)
    local animData = radioAnimations[currentRadioAnimation]
    LoadAnimDic(animData.dictionary)

    if pState then
        -- تشغيل الأنيميشن
        TaskPlayAnim(PlayerPedId(), animData.dictionary, animData.animation, 8.0, 0.0, -1, 49, 0, 0, 0, 0)

        -- رسبنة البروب
        radioProp = CreateObject(`prop_cs_hand_radio`, 0.0, 0.0, 0.0, true, true, false)

        -- استخدام إعدادات الموضع والدوران من الأنيميشن الحالي
        local propPos = animData.propPosition[1]
        local propRot = animData.propPosition[2]
        local boneIndex = GetPedBoneIndex(PlayerPedId(), animData.bone)

        -- ضبط موضع ودوران البروب باستخدام AttachEntityToEntity
        AttachEntityToEntity(
            radioProp, 
            PlayerPedId(), 
            boneIndex, -- العظمة المحددة
            propPos.x, propPos.y, propPos.z, 
            propRot.x, propRot.y, propRot.z, 
            true, -- ثبات الموضع
            false, 
            false, 
            false, 
            2, 
            true
        )
    else
        -- إيقاف الأنيميشن وتنظيف البروب
        StopAnimTask(PlayerPedId(), animData.dictionary, animData.animation, -4.0)
        ClearPedTasks(PlayerPedId())
        if radioProp ~= nil and DoesEntityExist(radioProp) then
            DeleteObject(radioProp)
            radioProp = nil
        end
    end
end


RegisterCommand('radio1', function()
    currentRadioAnimation = "radio1"
    print("Switched to Radio Animation 1")
end, false)

RegisterCommand('radio2', function()
    currentRadioAnimation = "radio2"
    print("Switched to Radio Animation 2")
end, false)

RegisterCommand('radio3', function()
    currentRadioAnimation = "radio3"
    print("Switched to Radio Animation 3")
end, false)
RegisterCommand('radio4', function()
    currentRadioAnimation = "radio4"
    print("Switched to Radio Animation 4")
end, false)

RegisterCommand('+radiotalk', function()
    if GetConvarInt('voice_enableRadios', 1) ~= 1 then return end
    if isDead() or LocalPlayer.state.disableRadio then return end

    if not radioPressed and radioEnabled then
        if radioChannel > 0 then
            logger.info('[radio] Start broadcasting, update targets and notify server.')
            playerTargets(radioData, MumbleIsPlayerTalking(PlayerId()) and callData or {})
            TriggerServerEvent('pma-voice:setTalkingOnRadio', true)
            radioPressed = true
            playMicClicks(true)
            if GetConvarInt('voice_enableRadioAnim', 0) == 1 and not (GetConvarInt('voice_disableVehicleRadioAnim', 0) == 1 and IsPedInAnyVehicle(PlayerPedId(), false)) and not disableRadioAnim then
                toggleRadioAnimation(true)
            end
            CreateThread(function()
                TriggerEvent("pma-voice:radioActive", true)
                while radioPressed and not LocalPlayer.state.disableRadio do
                    Wait(0)
                    SetControlNormal(0, 249, 1.0)
                    SetControlNormal(1, 249, 1.0)
                    SetControlNormal(2, 249, 1.0)
                end
            end)
        end
    end
end, false)


function isDead()
    if exports['qb-hospital']:isPlayerDead() then
        return true
    end
end

RegisterCommand('-radiotalk', function()
    if (radioChannel > 0 or radioEnabled) and radioPressed then
        radioPressed = false
        MumbleClearVoiceTargetPlayers(voiceTarget)
        playerTargets(MumbleIsPlayerTalking(PlayerId()) and callData or {})
        TriggerEvent("pma-voice:radioActive", false)
        playMicClicks(false)
        if GetConvarInt('voice_enableRadioAnim', 0) == 1 then
            toggleRadioAnimation(false)
        end
        TriggerServerEvent('pma-voice:setTalkingOnRadio', false)
    end
end, false)

if gameVersion == 'fivem' then
	RegisterKeyMapping('+radiotalk', 'Talk over Radio', 'keyboard', GetConvar('voice_defaultRadio', 'LMENU'))
end

--- event syncRadio
--- syncs the players radio, only happens if the radio was set server side.
---@param _radioChannel number the radio channel to set the player to.
function syncRadio(_radioChannel)
	if GetConvarInt('voice_enableRadios', 1) ~= 1 then return end
	logger.info('[radio] radio set serverside update to radio %s', radioChannel)
	radioChannel = _radioChannel
end
RegisterNetEvent('pma-voice:clSetPlayerRadio', syncRadio)
function LoadAnimDic(dict)
    if not HasAnimDictLoaded(dict) then
        RequestAnimDict(dict)
        while not HasAnimDictLoaded(dict) do
            Wait(0)
        end
    end
end